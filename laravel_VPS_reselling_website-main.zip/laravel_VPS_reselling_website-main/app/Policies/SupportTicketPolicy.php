<?php

declare(strict_types=1);

namespace App\Policies;

use Illuminate\Foundation\Auth\User as AuthUser;
use App\Models\SupportTicket;
use Illuminate\Auth\Access\HandlesAuthorization;

class SupportTicketPolicy
{
    use HandlesAuthorization;
    
    public function viewAny(AuthUser $authUser): bool
    {
        return $authUser->can('ViewAny:SupportTicket') || ! $authUser->is_suspended;
    }

    public function view(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('View:SupportTicket') || ($supportTicket->user_id === $authUser->id && ! $authUser->is_suspended);
    }

    public function create(AuthUser $authUser): bool
    {
        return $authUser->can('Create:SupportTicket') || ! $authUser->is_suspended;
    }

    public function update(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('Update:SupportTicket') || ($supportTicket->user_id === $authUser->id && ! $authUser->is_suspended);
    }

    public function delete(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('Delete:SupportTicket');
    }

    public function deleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('DeleteAny:SupportTicket');
    }

    public function restore(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('Restore:SupportTicket');
    }

    public function forceDelete(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('ForceDelete:SupportTicket');
    }

    public function forceDeleteAny(AuthUser $authUser): bool
    {
        return $authUser->can('ForceDeleteAny:SupportTicket');
    }

    public function restoreAny(AuthUser $authUser): bool
    {
        return $authUser->can('RestoreAny:SupportTicket');
    }

    public function replicate(AuthUser $authUser, SupportTicket $supportTicket): bool
    {
        return $authUser->can('Replicate:SupportTicket');
    }

    public function reorder(AuthUser $authUser): bool
    {
        return $authUser->can('Reorder:SupportTicket');
    }
}